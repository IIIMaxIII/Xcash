#!/usr/bin/env bash

eff_raw=`curl --connect-timeout 2 --max-time 10 --silent --noproxy '*' http://127.0.0.1:65056`

eff_total=$(jq '.results.hashes_total' <<< "$eff_raw")
eff_uptime=$(jq '.connection.uptime' <<< "$eff_raw")
eff_eff=$(( $eff_total / $eff_uptime))

#eff_eff=$(( $(jq '.results.hashes_total' <<< "$eff_raw") / $(jq '.connection.uptime' <<< "$eff_raw")))

echo '| total hashes :' $eff_total '| uptime :' $eff_uptime '| effective :' $eff_eff '|'
echo
find /var/log/miner/xmrigamd*/*.log -mmin 1 -exec cat {} + | grep -i 'error\|duplicate'